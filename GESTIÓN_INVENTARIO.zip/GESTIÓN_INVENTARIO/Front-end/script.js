// script.js
const API_URL = 'http://localhost:3000/api';

// Manejar el registro
document.getElementById('registerForm')?.addEventListener('submit', async (e) => {
    e.preventDefault();
    const fullname = document.getElementById('fullname').value;
    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;

    const response = await fetch(`${API_URL}/registro`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ nombre_completo: fullname, correo: email, clave: password })
    });

    if (response.ok) {
        alert('Usuario registrado con éxito.');
        window.location.href = 'login.html';
    } else {
        alert('Error al registrarse.');
    }
});

// Manejar el inicio de sesión
document.getElementById('loginForm')?.addEventListener('submit', async (e) => {
    e.preventDefault();
    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;

    const response = await fetch(`${API_URL}/login`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ correo: email, clave: password })
    });

    if (response.ok) {
        const data = await response.json();
        localStorage.setItem('token', data.token); // Guarda el token en localStorage
        window.location.href = 'dashboard.html'; // Redirige al dashboard
    } else {
        alert('Credenciales incorrectas.');
    }
});

// Función para cargar productos
async function loadProducts() {
    const response = await fetch(`${API_URL}/productos`, {
        headers: { 'Authorization': `Bearer ${localStorage.getItem('token')}` }
    });
    const products = await response.json();
    const tableBody = document.getElementById('productTableBody');

    products.forEach(product => {
        const row = `<tr>
            <td>${product.producto_id}</td>
            <td>${product.nombre}</td>
            <td>${product.codigo}</td>
            <td>
                <button class="btn btn-warning">Editar</button>
                <button class="btn btn-danger">Eliminar</button>
            </td>
        </tr>`;
        tableBody.innerHTML += row;
    });
}

// Cargar productos al abrir la página
if (document.getElementById('productTableBody')) {
    loadProducts();
}

// Verificar si el usuario está autenticado al cargar el dashboard
if (window.location.pathname === '/dashboard.html' && !localStorage.getItem('token')) {
    window.location.href = 'login.html'; // Redirigir al login si no está autenticado
}