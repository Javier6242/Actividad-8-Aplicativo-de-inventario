// Cargar las variables de entorno desde el archivo .env
require('dotenv').config();
const SECRET_KEY = process.env.SECRET_KEY;

const express = require("express");
const path = require("path");
const bodyParser = require("body-parser");
const cors = require("cors");
const routes = require('./routes'); // Asegúrate de que este archivo existe
const db = require('./db'); // Asegúrate de tener configurada la conexión a tu base de datos

const app = express();
const PORT = process.env.PORT || 3000; // Usa el puerto de la variable de entorno, o 3000 por defecto

// Middleware
app.use(cors());
app.use(bodyParser.json());

// Servir archivos estáticos desde la carpeta del frontend
app.use(express.static(path.join(__dirname, '../Front-end')));

// Rutas para el CRUD
app.use('/api', routes);

// Endpoint para obtener todos los usuarios
app.get('/api/users', async (req, res) => {
    try {
        const result = await db.query('SELECT * FROM usuario');
        res.json(result.rows);
    } catch (error) {
        console.error(error);
        res.status(500).json({ error: 'Error al obtener usuario.' });
    }
});

// Endpoint para eliminar un usuario
app.delete('/api/users/:id', async (req, res) => {
    const { id } = req.params;
    try {
        const result = await db.query('DELETE FROM usuario WHERE usuario_id = $1', [id]);
        if (result.rowCount === 0) {
            return res.status(404).json({ error: 'Usuario no encontrado.' });
        }
        res.json({ message: 'Usuario eliminado con éxito.' });
    } catch (error) {
        console.error(error);
        res.status(500).json({ error: 'Error al eliminar el usuario.' });
    }
});

// Ruta para servir el archivo index.html
app.get("/", (req, res) => {
  //res.send("Hello World!");
  res.sendFile(path.join(__dirname + "/index.html"));
});

// Ruta para servir el archivo usuarios.html
app.get("/usuarios", (req, res) => {
    res.sendFile(path.join(__dirname, "usuarios.html"));
});

// Iniciar el servidor
app.listen(3000, () => {
  console.log("Servidor ejecutándose en el puerto", 3000);
});
