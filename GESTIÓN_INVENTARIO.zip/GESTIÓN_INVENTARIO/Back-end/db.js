// db.js
const { Pool } = require('pg');

// Crear una instancia de Pool
const pool = new Pool({
    user: 'postgres', // Aquí va tu usuario de PostgreSQL
    host: 'localhost', // localhost si trabajas desde tu ordenador
    database: 'GESTION_INVENTARIO', // Aquí va el nombre de tu base de datos
    password: 'Universidad', // Aquí va la contraseña de PsotgreSQL
    port: 5432,
});

// Probar la conexión
pool.connect()
    .then(() => console.log("Conectado a la base de datos"))
    .catch(err => console.error("Error al conectar a la base de datos", err));

// Exportar el pool para usarlo en otros archivos
module.exports = pool;