// routes.js
const express = require('express');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const { body, validationResult } = require('express-validator'); // Importar express-validator
const router = express.Router();
const db = require('./db');
const authenticateToken = require('./middleware/auth'); // Importar el middleware

const SECRET_KEY = process.env.SECRET_KEY;

// Obtener todos los productos
router.get('/productos', async (req, res) => {
    const result = await db.query('SELECT * FROM producto_articulo');
    res.json(result.rows);
});

// Agregar un nuevo producto
router.post('/productos', async (req, res) => {
    const { nombre, codigo, descripcion, precio_unitario, stock, categoria_id, marca, unidad_medida } = req.body;
    const result = await db.query(
        'INSERT INTO producto_articulo (nombre, codigo, descripcion, precio_unitario, stock, categoria_id, marca, unidad_medida) VALUES ($1, $2, $3, $4, $5, $6, $7, $8) RETURNING *',
        [nombre, codigo, descripcion, precio_unitario, stock, categoria_id, marca, unidad_medida]
    );
    res.status(201).json(result.rows[0]);
});

// Actualizar un producto
router.put('/productos/:id', authenticateToken, async (req, res) => {
    const { id } = req.params;
    const { nombre, codigo, descripcion, precio_unitario, stock, categoria_id, marca, unidad_medida } = req.body;
    const result = await db.query(
        'UPDATE producto_articulo SET nombre = $1, codigo = $2, descripcion = $3, precio_unitario = $4, stock = $5, categoria_id = $6, marca = $7, unidad_medida = $8 WHERE producto_id = $9 RETURNING *',
        [nombre, codigo, descripcion, precio_unitario, stock, categoria_id, marca, unidad_medida, id]
    );
    res.json(result.rows[0]);
});

// Eliminar un producto
router.delete('/productos/:id', async (req, res) => {
    const { id } = req.params;
    await db.query('DELETE FROM producto_articulo WHERE producto_id = $1', [id]);
    res.sendStatus(204);
});

// --- Endpoints para Usuarios ---
// Obtener todos los usuarios
router.get('/usuarios', authenticateToken, async (req, res) => {
    const result = await db.query('SELECT * FROM usuario');
    res.json(result.rows);
});

// Obtener un usuario específico
router.get('/usuarios/:id', async (req, res) => {
    const { id } = req.params;
    const result = await db.query('SELECT * FROM usuario WHERE usuario_id = $1', [id]);
    if (result.rows.length === 0) return res.status(404).json({ error: 'Usuario no encontrado' });
    res.json(result.rows[0]);
});

// Registro de usuario
router.post('/registro', [
    body('nombre_completo').notEmpty().withMessage('El nombre completo es requerido.'),
    body('correo').isEmail().withMessage('Debe ser un correo electrónico válido.'),
    body('telefono').optional().notEmpty().withMessage('El teléfono es requerido si se proporciona.'),
    body('direccion').optional().notEmpty().withMessage('La dirección es requerida si se proporciona.'),
    body('tipo_documento').optional().notEmpty().withMessage('El tipo de documento es requerido si se proporciona.'),
    body('num_documento').optional().notEmpty().withMessage('El número de documento es requerido si se proporciona.'),
    body('clave').isLength({ min: 6 }).withMessage('La contraseña debe tener al menos 6 caracteres.')
], async (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
        return res.status(400).json({ errors: errors.array() });
    }

    const { nombre_completo, correo, telefono, direccion, tipo_documento, num_documento, clave } = req.body;
    const hashedPassword = await bcrypt.hash(clave, 10); // Encriptar contraseña

    try {
        const result = await db.query(
            'INSERT INTO usuario (nombre_completo, correo, telefono, direccion, tipo_documento, num_documento, clave_hash, rol) VALUES ($1, $2, $3, $4, $5, $6, $7, $8) RETURNING *',
            [nombre_completo, correo, telefono, direccion, tipo_documento, num_documento, hashedPassword, 'cliente'] // Asumimos rol 'cliente'
        );
        res.status(201).json(result.rows[0]);
    } catch (error) {
        res.status(400).json({ error: 'Error al registrar el usuario' });
    }
});

// Registro de usuario administrador
router.post('/registro/admin', async (req, res) => {
    const { nombre_completo, correo, clave } = req.body; // Simplificado para el administrador

    const hashedPassword = await bcrypt.hash(clave, 10);

    try {
        const result = await db.query(
            'INSERT INTO usuario (nombre_completo, correo, clave_hash, rol) VALUES ($1, $2, $3, $4) RETURNING *',
            [nombre_completo, correo, hashedPassword, 'administrador'] // Asignar rol 'administrador'
        );
        res.status(201).json(result.rows[0]);
    } catch (error) {
        res.status(400).json({ error: 'Error al registrar el usuario administrador' });
    }
});

// Actualizar un usuario
router.put('/usuarios/:id', authenticateToken, async (req, res) => {
    const { id } = req.params;
    const { nombre_completo, correo, telefono, direccion, tipo_documento, num_documento, clave } = req.body;
    const hashedPassword = await bcrypt.hash(clave, 10);
    const result = await db.query(
        'UPDATE usuario SET nombre_completo = $1, correo = $2, telefono = $3, direccion = $4, tipo_documento = $5, num_documento = $6, clave_hash = $7 WHERE usuario_id = $8 RETURNING *',
        [nombre_completo, correo, telefono, direccion, tipo_documento, num_documento, hashedPassword, id]
    );
    if (result.rows.length === 0) return res.status(404).json({ error: 'Usuario no encontrado' });
    res.json(result.rows[0]);
});

// Eliminar un usuario
router.delete('/usuarios/:id', authenticateToken, async (req, res) => {
    const { id } = req.params;
    await db.query('DELETE FROM usuario WHERE usuario_id = $1', [id]);
    res.sendStatus(204);
});

// Obtener todos los movimientos
router.get('/movimientos', authenticateToken, async (req, res) => {
    const result = await db.query('SELECT * FROM historial_movimientos');
    res.json(result.rows);
});

// Obtener un movimiento específico
router.get('/movimientos/:id', authenticateToken, async (req, res) => {
    const { id } = req.params;
    const result = await db.query('SELECT * FROM historial_movimientos WHERE movimiento_id = $1', [id]);
    if (result.rows.length === 0) return res.status(404).json({ error: 'Movimiento no encontrado' });
    res.json(result.rows[0]);
});

// Crear un nuevo movimiento
router.post('/movimientos', authenticateToken, async (req, res) => {
    const { producto_id, usuario_id, tipo_movimiento, cantidad, precio_unitario, detalle, tipo_comprobante, num_comprobante } = req.body;
    const result = await db.query(
        'INSERT INTO historial_movimientos (producto_id, usuario_id, tipo_movimiento, cantidad, precio_unitario, detalle, tipo_comprobante, num_comprobante) VALUES ($1, $2, $3, $4, $5, $6, $7, $8) RETURNING *',
        [producto_id, usuario_id, tipo_movimiento, cantidad, precio_unitario, detalle, tipo_comprobante, num_comprobante]
    );
    res.status(201).json(result.rows[0]);
});

// Actualizar un movimiento
router.put('/movimientos/:id', authenticateToken, async (req, res) => {
    const { id } = req.params;
    const { producto_id, usuario_id, tipo_movimiento, cantidad, precio_unitario, detalle, tipo_comprobante, num_comprobante } = req.body;
    const result = await db.query(
        'UPDATE historial_movimientos SET producto_id = $1, usuario_id = $2, tipo_movimiento = $3, cantidad = $4, precio_unitario = $5, detalle = $6, tipo_comprobante = $7, num_comprobante = $8 WHERE movimiento_id = $9 RETURNING *',
        [producto_id, usuario_id, tipo_movimiento, cantidad, precio_unitario, detalle, tipo_comprobante, num_comprobante, id]
    );
    if (result.rows.length === 0) return res.status(404).json({ error: 'Movimiento no encontrado' });
    res.json(result.rows[0]);
});

// Eliminar un movimiento
router.delete('/movimientos/:id', authenticateToken, async (req, res) => {
    const { id } = req.params;
    await db.query('DELETE FROM historial_movimientos WHERE movimiento_id = $1', [id]);
    res.sendStatus(204);
});

// Inicio de sesión
router.post('/login', [
    body('correo').isEmail().withMessage('Debe ser un correo electrónico válido.'),
    body('clave').notEmpty().withMessage('La contraseña es requerida.')
], async (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
        return res.status(400).json({ errors: errors.array() });
    }
    
    const { correo, clave } = req.body;

    try {
        const user = await db.query('SELECT * FROM usuario WHERE correo = $1', [correo]);
        
        if (user.rows.length > 0) {
            const isValid = await bcrypt.compare(clave, user.rows[0].clave_hash);
            if (isValid) {
                const token = jwt.sign({ id: user.rows[0].usuario_id, rol: user.rows[0].rol }, SECRET_KEY, { expiresIn: '1h' });
                return res.json({ token });
            }
        }
        res.status(401).json({ error: 'Credenciales incorrectas' });
    } catch (error) {
        res.status(500).json({ error: 'Error en el inicio de sesión' });
    }
});

module.exports = router;
