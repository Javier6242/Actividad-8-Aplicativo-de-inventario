const express = require('express');
const bodyParser = require('body-parser');
const { Pool } = require('pg');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');

const app = express();
const port = 3000;
const SECRET_KEY = 'your_secret_jwt_key'; // Cambiar por variable de entorno en producción

app.use(bodyParser.json());

// Configura la conexión a PostgreSQL
const pool = new Pool({
  user: 'postgres',       // cambia según tu config
  host: 'localhost',      // o IP de tu servidor PostgreSQL
  database: 'tu_base_de_datos', // cambia por tu DB
  password: 'tu_contraseña',    // cambia según config
  port: 5432
});

// Middleware para verificar token JWT en rutas protegidas
const authenticateToken = (req, res, next) => {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];
  if(!token) return res.status(401).json({message: 'Token requerido'});

  jwt.verify(token, SECRET_KEY, (err, user) => {
    if(err) return res.status(403).json({message: 'Token inválido'});
    req.user = user;
    next();
  });
};

// -------- RUTAS DE AUTENTICACIÓN --------

// Registro de usuario
app.post('/register', async (req, res) => {
  const { nombre, correo, rol, contraseña } = req.body;
  if(!nombre || !correo || !rol || !contraseña) {
    return res.status(400).json({message: 'Faltan datos'});
  }
  try {
    const hash = await bcrypt.hash(contraseña, 10);
    await pool.query(
      'INSERT INTO usuarios (nombre, correo, rol, contraseña, estado) VALUES ($1,$2,$3,$4, true)',
      [nombre, correo, rol, hash]
    );
    res.status(201).json({message: 'Usuario registrado'});
  } catch (error) {
    if(error.code === '23505') { // clave única (correo) violada
      res.status(409).json({message: 'Correo ya registrado'});
    } else {
      res.status(500).json({message: 'Error del servidor'});
    }
  }
});

// Login de usuario
app.post('/login', async (req, res) => {
  const { correo, contraseña } = req.body;
  if(!correo || !contraseña) {
    return res.status(400).json({message: 'Faltan datos'});
  }
  try {
    const result = await pool.query('SELECT * FROM usuarios WHERE correo=$1', [correo]);
    if(result.rowCount === 0) {
      return res.status(401).json({message: 'Correo o contraseña inválidos'});
    }
    const user = result.rows[0];
    const match = await bcrypt.compare(contraseña, user.contraseña);
    if(!match) {
      return res.status(401).json({message: 'Correo o contraseña inválidos'});
    }
    const token = jwt.sign({ id: user.id, correo: user.correo, rol: user.rol }, SECRET_KEY, { expiresIn: '2h' });
    res.json({ token });
  } catch (error) {
    res.status(500).json({message: 'Error del servidor'});
  }
});

// -------- CRUD para productos --------

// Obtener todos los productos (público)
app.get('/productos', async (req, res) => {
  try {
    const result = await pool.query('SELECT * FROM productos ORDER BY id ASC');
    res.json(result.rows);
  } catch (error) {
    res.status(500).json({message: 'Error al obtener productos'});
  }
});

// Obtener producto por ID (público)
app.get('/productos/:id', async (req, res) => {
  const id = parseInt(req.params.id);
  try {
    const result = await pool.query('SELECT * FROM productos WHERE id=$1', [id]);
    if(result.rowCount === 0) {
      return res.status(404).json({message: 'Producto no encontrado'});
    }
    res.json(result.rows[0]);
  } catch (error) {
    res.status(500).json({message: 'Error al obtener producto'});
  }
});

// Crear nuevo producto (protegido)
app.post('/productos', authenticateToken, async (req, res) => {
  const { codigo, nombre, descripcion, precio, cantidad_stock, categoria_id, proveedor_id } = req.body;
  if(!codigo || !nombre || precio == null || cantidad_stock == null || !categoria_id) {
    return res.status(400).json({message: 'Faltan datos obligatorios'});
  }
  try {
    await pool.query(
      `INSERT INTO productos (codigo, nombre, descripcion, precio, cantidad_stock, categoria_id, proveedor_id)
       VALUES ($1,$2,$3,$4,$5,$6,$7)`,
      [codigo, nombre, descripcion, precio, cantidad_stock, categoria_id, proveedor_id]
    );
    res.status(201).json({message: 'Producto creado'});
  } catch (error) {
    if(error.code === '23505') {
      res.status(409).json({message: 'Código de producto ya existe'});
    } else {
      res.status(500).json({message: 'Error al crear producto'});
    }
  }
});

// Actualizar producto por ID (protegido)
app.put('/productos/:id', authenticateToken, async (req, res) => {
  const id = parseInt(req.params.id);
  const { codigo, nombre, descripcion, precio, cantidad_stock, categoria_id, proveedor_id } = req.body;
  try {
    const result = await pool.query('SELECT * FROM productos WHERE id=$1', [id]);
    if(result.rowCount === 0) {
      return res.status(404).json({message: 'Producto no encontrado'});
    }
    await pool.query(
      `UPDATE productos SET codigo=$1, nombre=$2, descripcion=$3, precio=$4, cantidad_stock=$5, categoria_id=$6, proveedor_id=$7 WHERE id=$8`,
      [codigo, nombre, descripcion, precio, cantidad_stock, categoria_id, proveedor_id, id]
    );
    res.json({message: 'Producto actualizado'});
  } catch (error) {
    res.status(500).json({message: 'Error al actualizar producto'});
  }
});

// Eliminar producto por ID (protegido)
app.delete('/productos/:id', authenticateToken, async (req, res) => {
  const id = parseInt(req.params.id);
  try {
    const result = await pool.query('SELECT * FROM productos WHERE id=$1', [id]);
    if(result.rowCount === 0) {
      return res.status(404).json({message: 'Producto no encontrado'});
    }
    await pool.query('DELETE FROM productos WHERE id=$1', [id]);
    res.json({message: 'Producto eliminado'});
  } catch (error) {
    res.status(500).json({message: 'Error al eliminar producto'});
  }
});

// Endpoint raíz simple
app.get('/', (req, res) => {
  res.json({ info: 'API de inventario funcionando' });
});

app.listen(port, () => {
  console.log(`Servidor escuchando en http://localhost:${port}`);
});
