// middleware/auth.js
const jwt = require('jsonwebtoken');

const SECRET_KEY = process.env.SECRET_KEY; // Debe coincidir con la clave en el archivo de rutas

const authenticateToken = (req, res, next) => {
    // Obtener el token del encabezado de autorización
    const token = req.headers['authorization'] && req.headers['authorization'].split(' ')[1];

    // Si no hay token, retornar 401
    if (!token) return res.sendStatus(401);

    // Verificar el token
    jwt.verify(token, SECRET_KEY, (err, user) => {
        if (err) return res.sendStatus(403); // Token inválido
        req.user = user; // Almacenar información del usuario en la solicitud
        next(); // Continuar al siguiente middleware o ruta
    });
};

module.exports = authenticateToken;